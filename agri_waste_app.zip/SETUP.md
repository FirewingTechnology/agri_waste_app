# Agri Waste to Fertilizer - Setup Guide

## 🎯 Complete Setup Instructions

This guide will help you set up the project from scratch.

---

## 📋 Prerequisites

### Required Software

1. **Flutter SDK** (Version 3.0 or higher)
   - Download: https://docs.flutter.dev/get-started/install
   - Verify: `flutter doctor`

2. **Android Studio**
   - Download: https://developer.android.com/studio
   - Install Android SDK
   - Setup Android Emulator

3. **VS Code** (Recommended)
   - Download: https://code.visualstudio.com/
   - Install Extensions:
     - Flutter
     - Dart
     - GitHub Copilot

4. **Git**
   - Download: https://git-scm.com/

---

## 🚀 Step-by-Step Setup

### Step 1: Flutter Installation

```bash
# Verify Flutter installation
flutter doctor

# Expected output should show:
# ✓ Flutter
# ✓ Android toolchain
# ✓ VS Code
```

### Step 2: Project Setup

```bash
# Navigate to project directory
cd C:\agri_waste_app

# Install dependencies
flutter pub get

# Verify project
flutter analyze
```

### Step 3: Firebase Setup

1. **Create Firebase Project**
   - Go to https://console.firebase.google.com/
   - Click "Add Project"
   - Name: "agri-waste-app"
   - Enable Google Analytics (optional)

2. **Add Android App**
   - Click "Add app" → Android
   - Package name: `com.example.agri_waste_app`
   - Download `google-services.json`
   - Place in: `android/app/google-services.json`

3. **Enable Services**
   - **Authentication**: Email/Password
   - **Firestore Database**: Start in production mode
   - **Storage**: Default rules

4. **Configure Android**

Update `android/build.gradle`:
```gradle
dependencies {
    classpath 'com.google.gms:google-services:4.3.15'
}
```

Update `android/app/build.gradle`:
```gradle
apply plugin: 'com.google.gms.google-services'
```

### Step 4: Google Maps Setup

1. **Get API Key**
   - Go to: https://console.cloud.google.com/
   - Enable "Maps SDK for Android"
   - Create API key

2. **Add to AndroidManifest.xml**

File: `android/app/src/main/AndroidManifest.xml`

```xml
<application>
    <meta-data
        android:name="com.google.android.geo.API_KEY"
        android:value="YOUR_GOOGLE_MAPS_API_KEY"/>
</application>
```

### Step 5: OpenAI API Setup (Chatbot)

1. **Get API Key**
   - Sign up: https://platform.openai.com/
   - Create API key

2. **Update chatbot_service.dart**

```dart
static const String _apiKey = 'YOUR_OPENAI_API_KEY';
```

---

## 🔧 Configuration Files

### pubspec.yaml

Ensure all dependencies are added:

```yaml
dependencies:
  flutter:
    sdk: flutter
  firebase_core: ^2.24.2
  firebase_auth: ^4.16.0
  cloud_firestore: ^4.14.0
  firebase_storage: ^11.5.6
  provider: ^6.1.1
  google_fonts: ^6.1.0
  shared_preferences: ^2.2.2
  google_maps_flutter: ^2.5.0
  geolocator: ^10.1.0
  image_picker: ^1.0.5
  http: ^1.1.2
  uuid: ^4.2.2
  intl: ^0.18.1
```

Run:
```bash
flutter pub get
```

---

## 📱 Running the App

### On Emulator

```bash
# List available devices
flutter devices

# Run on emulator
flutter run
```

### On Physical Device

1. Enable Developer Options on Android
2. Enable USB Debugging
3. Connect via USB
4. Run: `flutter run`

---

## 🧪 Testing

### Run Tests
```bash
flutter test
```

### Check for Issues
```bash
flutter analyze
```

### Build APK
```bash
# Debug APK
flutter build apk --debug

# Release APK
flutter build apk --release
```

---

## 🔐 Firestore Security Rules

In Firebase Console → Firestore → Rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users collection
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId;
    }
    
    // Waste posts
    match /waste_posts/{postId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      allow update, delete: if request.auth.uid == resource.data.farmerId;
    }
    
    // Fertilizers
    match /fertilizers/{fertilizerId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      allow update, delete: if request.auth.uid == resource.data.processorId;
    }
    
    // Orders
    match /orders/{orderId} {
      allow read: if request.auth != null && 
        (request.auth.uid == resource.data.buyerId || 
         request.auth.uid == resource.data.sellerId);
      allow create: if request.auth != null;
      allow update: if request.auth.uid == resource.data.buyerId || 
                       request.auth.uid == resource.data.sellerId;
    }
  }
}
```

---

## 🎨 VS Code Setup

### Recommended Extensions

1. Flutter
2. Dart
3. GitHub Copilot
4. Pubspec Assist
5. Flutter Tree
6. Error Lens

### Settings (settings.json)

```json
{
  "dart.flutterSdkPath": "C:\\flutter",
  "editor.formatOnSave": true,
  "dart.lineLength": 100,
  "editor.suggestSelection": "first"
}
```

---

## 🐛 Common Issues & Solutions

### Issue 1: Flutter not recognized
```bash
# Add Flutter to PATH
# Windows: Edit System Environment Variables
# Add: C:\flutter\bin
```

### Issue 2: Gradle build failed
```bash
# Clean build
flutter clean
flutter pub get
flutter run
```

### Issue 3: Firebase not initialized
```bash
# Make sure google-services.json is in android/app/
# Uncomment Firebase initialization in main.dart
```

### Issue 4: Maps not showing
```bash
# Verify API key in AndroidManifest.xml
# Enable Maps SDK in Google Cloud Console
```

---

## 📊 Database Structure

### Firestore Collections

**users/**
```json
{
  "id": "user123",
  "name": "John Doe",
  "email": "john@example.com",
  "role": "Farmer",
  "phone": "9876543210",
  "createdAt": "timestamp"
}
```

**waste_posts/**
```json
{
  "id": "waste123",
  "farmerId": "user123",
  "wasteType": "Crop Residue",
  "quantity": 200,
  "pricePerKg": 5,
  "location": "Pune",
  "status": "available",
  "createdAt": "timestamp"
}
```

**fertilizers/**
```json
{
  "id": "fert123",
  "processorId": "user456",
  "fertilizerName": "Organic Compost",
  "quantity": 500,
  "pricePerKg": 25,
  "deliveryAvailable": true,
  "createdAt": "timestamp"
}
```

---

## 🚀 Deployment

### Generate Release APK

1. **Create Keystore**
```bash
keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

2. **Create key.properties**

File: `android/key.properties`
```properties
storePassword=yourPassword
keyPassword=yourPassword
keyAlias=upload
storeFile=upload-keystore.jks
```

3. **Build Release APK**
```bash
flutter build apk --release
```

APK Location: `build/app/outputs/flutter-apk/app-release.apk`

---

## ✅ Final Checklist

- [ ] Flutter installed and verified
- [ ] Firebase project created
- [ ] google-services.json added
- [ ] Google Maps API key configured
- [ ] OpenAI API key added
- [ ] Dependencies installed
- [ ] App runs on emulator
- [ ] Firebase initialized
- [ ] Database rules configured
- [ ] Release APK generated

---

## 📞 Support

If you encounter issues:

1. Check `flutter doctor`
2. Review error messages
3. Clean and rebuild: `flutter clean && flutter pub get`
4. Check Firebase configuration
5. Verify API keys

---

**Setup Complete! You're ready to develop! 🎉**
