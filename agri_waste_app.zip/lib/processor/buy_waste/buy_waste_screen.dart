import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../models/waste_model.dart';

// Fetch waste posts from Firestore
// Show farmer name, waste type, quantity, location
// Add interest / buy button

class BuyWasteScreen extends StatefulWidget {
  const BuyWasteScreen({super.key});

  @override
  State<BuyWasteScreen> createState() => _BuyWasteScreenState();
}

class _BuyWasteScreenState extends State<BuyWasteScreen> {
  bool _isLoading = true;
  final List<WasteModel> _wastePosts = [];

  @override
  void initState() {
    super.initState();
    _loadWastePosts();
  }

  Future<void> _loadWastePosts() async {
    // TODO: Load from Firestore
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
      // Add sample data
      _wastePosts.addAll([
        WasteModel(
          id: '1',
          farmerId: 'farmer1',
          farmerName: 'Ramesh Kumar',
          farmerPhone: '9876543210',
          wasteType: 'Crop Residue',
          quantity: 200,
          description: 'Fresh wheat straw available',
          location: 'Pune, Maharashtra',
          pricePerKg: 5,
          createdAt: DateTime.now(),
        ),
      ]);
    });
  }

  void _showInterestDialog(WasteModel waste) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Express Interest'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${waste.wasteType} - ${waste.quantity} kg'),
            const SizedBox(height: 8),
            Text('Farmer: ${waste.farmerName}'),
            const SizedBox(height: 8),
            Text('Location: ${waste.location}'),
            const SizedBox(height: 16),
            const Text('Contact the farmer to discuss details and pricing.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Call ${waste.farmerPhone} to discuss'),
                  backgroundColor: AppTheme.primaryGreen,
                ),
              );
            },
            icon: const Icon(Icons.phone),
            label: const Text('Contact'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buy Waste'),
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _wastePosts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.inventory_2_outlined,
                          size: 80, color: Colors.grey.shade400),
                      const SizedBox(height: 16),
                      Text(
                        'No waste posts available',
                        style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadWastePosts,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _wastePosts.length,
                    itemBuilder: (context, index) {
                      final waste = _wastePosts[index];
                      return _WasteCard(
                        waste: waste,
                        onInterest: () => _showInterestDialog(waste),
                      );
                    },
                  ),
                ),
    );
  }
}

class _WasteCard extends StatelessWidget {
  final WasteModel waste;
  final VoidCallback onInterest;

  const _WasteCard({
    required this.waste,
    required this.onInterest,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    waste.wasteType,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryGreen.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${waste.quantity} kg',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.primaryGreen,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              waste.description,
              style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.person, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 6),
                Text(
                  waste.farmerName,
                  style: const TextStyle(fontSize: 14, color: AppTheme.textSecondary),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.location_on, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 6),
                Text(
                  waste.location,
                  style: const TextStyle(fontSize: 14, color: AppTheme.textSecondary),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (waste.pricePerKg != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Expected Price',
                        style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                      ),
                      Text(
                        '₹${waste.pricePerKg}/kg',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.primaryGreen,
                        ),
                      ),
                    ],
                  )
                else
                  const Text('Price: Negotiable'),
                ElevatedButton.icon(
                  onPressed: onInterest,
                  icon: const Icon(Icons.phone),
                  label: const Text('Contact'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
