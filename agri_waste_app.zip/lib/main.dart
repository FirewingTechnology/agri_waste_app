import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth/language_selection.dart';
import 'auth/login_screen.dart';
import 'farmer/farmer_dashboard.dart';
import 'processor/processor_dashboard.dart';
import 'core/theme/app_theme.dart';

// Create Flutter app entry point with MaterialApp
// Add routes for login, farmer dashboard and processor dashboard
// Use theme and initial route as language selection

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // TODO: Initialize Firebase
  // await Firebase.initializeApp();
  
  runApp(const AgriWasteApp());
}

class AgriWasteApp extends StatelessWidget {
  const AgriWasteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Agri Waste to Fertilizer',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      initialRoute: '/',
      routes: {
        '/': (context) => const LanguageSelectionScreen(),
        '/login': (context) => const LoginScreen(),
        '/farmer-dashboard': (context) => const FarmerDashboard(),
        '/processor-dashboard': (context) => const ProcessorDashboard(),
      },
    );
  }
}
